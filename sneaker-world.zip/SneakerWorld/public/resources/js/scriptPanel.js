function showModalConnexion(){
    $('#connexionModal').modal('show');
}