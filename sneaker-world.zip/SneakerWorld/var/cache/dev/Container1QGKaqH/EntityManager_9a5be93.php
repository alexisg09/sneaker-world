<?php

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $valueHolder99720 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializere4fa5 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties0e69e = [
        
    ];

    public function getConnection()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'getConnection', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'getMetadataFactory', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'getExpressionBuilder', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'beginTransaction', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->beginTransaction();
    }

    public function getCache()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'getCache', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->getCache();
    }

    public function transactional($func)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'transactional', array('func' => $func), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->transactional($func);
    }

    public function commit()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'commit', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->commit();
    }

    public function rollback()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'rollback', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'getClassMetadata', array('className' => $className), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'createQuery', array('dql' => $dql), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'createNamedQuery', array('name' => $name), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'createQueryBuilder', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'flush', array('entity' => $entity), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'clear', array('entityName' => $entityName), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->clear($entityName);
    }

    public function close()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'close', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->close();
    }

    public function persist($entity)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'persist', array('entity' => $entity), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'remove', array('entity' => $entity), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'refresh', array('entity' => $entity), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'detach', array('entity' => $entity), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'merge', array('entity' => $entity), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'getRepository', array('entityName' => $entityName), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'contains', array('entity' => $entity), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'getEventManager', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'getConfiguration', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'isOpen', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'getUnitOfWork', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'getProxyFactory', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'initializeObject', array('obj' => $obj), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'getFilters', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'isFiltersStateClean', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'hasFilters', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return $this->valueHolder99720->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializere4fa5 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder99720) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder99720 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder99720->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, '__get', ['name' => $name], $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        if (isset(self::$publicProperties0e69e[$name])) {
            return $this->valueHolder99720->$name;
        }

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder99720;

            $backtrace = debug_backtrace(false);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    get_parent_class($this),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
            return;
        }

        $targetObject = $this->valueHolder99720;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, '__set', array('name' => $name, 'value' => $value), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder99720;

            return $targetObject->$name = $value;
            return;
        }

        $targetObject = $this->valueHolder99720;
        $accessor = function & () use ($targetObject, $name, $value) {
            return $targetObject->$name = $value;
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, '__isset', array('name' => $name), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder99720;

            return isset($targetObject->$name);
            return;
        }

        $targetObject = $this->valueHolder99720;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, '__unset', array('name' => $name), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder99720;

            unset($targetObject->$name);
            return;
        }

        $targetObject = $this->valueHolder99720;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __clone()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, '__clone', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        $this->valueHolder99720 = clone $this->valueHolder99720;
    }

    public function __sleep()
    {
        $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, '__sleep', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;

        return array('valueHolder99720');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null)
    {
        $this->initializere4fa5 = $initializer;
    }

    public function getProxyInitializer()
    {
        return $this->initializere4fa5;
    }

    public function initializeProxy() : bool
    {
        return $this->initializere4fa5 && ($this->initializere4fa5->__invoke($valueHolder99720, $this, 'initializeProxy', array(), $this->initializere4fa5) || 1) && $this->valueHolder99720 = $valueHolder99720;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder99720;
    }

    public function getWrappedValueHolderValue() : ?object
    {
        return $this->valueHolder99720;
    }


}
